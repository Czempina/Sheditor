namespace Editor {
    public class Cursor {
        public int Row { get; set; }
        
        public int Col { get; set; }
    }
}