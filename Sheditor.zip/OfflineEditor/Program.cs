﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Editor
{
    class Program
    {
        static void Main(string[] args)
        {
            new Editor();
        }
    }
}
